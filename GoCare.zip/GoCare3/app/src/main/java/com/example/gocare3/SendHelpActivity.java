package com.example.gocare3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SendHelpActivity extends AppCompatActivity {

    enum Sex
    {
        MALE, FEMALE
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_help);
        Button M_Button = (Button) findViewById(R.id.M_Button);
        Button F_Button = (Button) findViewById(R.id.F_Button);
        Button Submit_Button = (Button) findViewById(R.id.Submit_Button);
    }

    public void M_ButtonClick(View view) {
        //when you click left button do this:
        Button M_Button = (Button) findViewById(R.id.M_Button);
        Sex s1 = Sex.MALE;
    }

    public void F_ButtonClick(View view) {
        //when you click left button do this:
        Button F_Button = (Button) findViewById(R.id.F_Button);
        Sex s1 = Sex.FEMALE;
    }

    public void Submit_ButtonClick(View view) {
        //when you click left button do this:
        Button Submit_Button = (Button) findViewById(R.id.Submit_Button);
    }

}
